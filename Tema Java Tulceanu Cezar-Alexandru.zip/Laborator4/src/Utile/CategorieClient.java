package Utile;

public enum CategorieClient {
    BASIC,SILVER,PREMIUM
}
