package Utile;

public class ClientUtils {
    public static int idCurent = 1;
}
