package Utile;

public class Constante {
    public static final String NUME_FISIER = "C:\\Users\\40765\\Desktop\\Laborator4\\src\\Resources\\produse.txt";
}
