package Utile;

public enum Status {
    NEPROCESAT,
    PROCESAT
}
